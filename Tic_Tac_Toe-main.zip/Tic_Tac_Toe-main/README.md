﻿# Tic Tac Toe
Tic-Tac-Toe is a classic two-player game where the objective is to be the first to form a line of three marks (either 'X' or 'O') on a 3x3 grid. This project provides a simple and interactive implementation of the game, allowing two players to compete against each other.



https://github.com/user-attachments/assets/633937b0-29d0-41a5-9634-8eca5d624280

